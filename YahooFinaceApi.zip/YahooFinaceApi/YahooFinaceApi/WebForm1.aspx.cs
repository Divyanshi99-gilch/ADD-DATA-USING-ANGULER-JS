﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace YahooFinaceApi
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public class User
        {
            public string Username { get; set; }
           
        }
        //[WebMethod]
        //[ScriptMethod]
        //public static void SaveUser(User user)
        //{
        //    string constr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        //    using (SqlConnection con = new SqlConnection(constr))
        //    {
        //        using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_YahooFinace VALUES(@Exchange)"))
        //        {
        //            cmd.CommandType = CommandType.Text;

        //            cmd.Parameters.AddWithValue("@Exchange", user.Username);
        //         //   cmd.Parameters.AddWithValue("@Password", user.Password);
        //            cmd.Connection = con;
        //            con.Open();
        //            cmd.ExecuteNonQuery();
        //            con.Close();
        //        }
        //    }
        //}
    }
}