﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace YahooFinaceApi
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        public static string Constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
      
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static string SaveData(string empdata)//WebMethod to Save the data  
        {
            var serializeData = JsonConvert.DeserializeObject<List<Employee>>(empdata);
            using (var con = new SqlConnection(Constr))
            {
                foreach (var data in serializeData)
                {
                    using (var cmd = new SqlCommand("INSERT INTO Employee VALUES(@Fname, @Lname,@Email,@CreatedDate)"))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Fname", data.FName);
                        cmd.Parameters.AddWithValue("@Lname", data.LName);
                        cmd.Parameters.AddWithValue("@Email", data.EmailId);
                        cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                        cmd.Connection = con;
                        if (con.State == ConnectionState.Closed)
                        {
                            con.Open();
                        }
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }
            return null;
        }  
    }
}